<?php

//Dont Change THis
$Email = "web.securemailer@gmail.com";
$Password = "tbqqrpzviixlprxn";
$Name = "Mavericks";


//ADD Email of Owner
$OwnerEmail = "mavericksracing@gmail.com";
?>