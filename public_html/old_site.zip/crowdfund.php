<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Mavericks Racing</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700|Raleway:300,400,400i,500,500i,700,800,900" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/nivo-slider/css/nivo-slider.css" rel="stylesheet">
  <link href="lib/owlcarousel/owl.carousel.css" rel="stylesheet">
  <link href="lib/owlcarousel/owl.transitions.css" rel="stylesheet">
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/venobox/venobox.css" rel="stylesheet">

  <!-- Nivo Slider Theme -->
  <link href="css/nivo-slider-theme.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">

  <!-- Responsive Stylesheet File -->
  <link href="css/responsive.css" rel="stylesheet">
  
  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/venobox/venobox.min.js"></script>
  <script src="lib/knob/jquery.knob.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/parallax/parallax.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/nivo-slider/js/jquery.nivo.slider.js" type="text/javascript"></script>
  <script src="lib/appear/jquery.appear.js"></script>
  <script src="lib/isotope/isotope.pkgd.min.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <script src="js/main.js"></script>
  <!-- =======================================================
    Theme Name: eBusiness
    Theme URL: https://bootstrapmade.com/ebusiness-bootstrap-corporate-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
  ======================================================= -->
</head>

<body data-spy="scroll" data-target="#navbar-example">

  <div id="preloader"></div>

  <header>
    <!-- header-area start -->
    <div id="sticker" class="header-area">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12">

            <!-- Navigation -->
            <nav class="navbar navbar-default">
              <!-- Brand and toggle get grouped for better mobile display -->
              <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".bs-example-navbar-collapse-1" aria-expanded="false">
										<span class="sr-only">Toggle navigation</span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
									</button>
                <!-- Brand -->
                <a class="navbar-brand page-scroll sticky-logo" href="index.html">
                  <h1><span>M</span>avericks</h1>
                  <!-- Uncomment below if you prefer to use an image logo -->
                  <!-- <img src="img/logo.png" alt="" title=""> -->
								</a>
              </div>
              <!-- Collect the nav links, forms, and other content for toggling -->
              <div class="collapse navbar-collapse main-menu bs-example-navbar-collapse-1" id="navbar-example">
                <ul class="nav navbar-nav navbar-right">
                  <li>
                    <a class="page-scroll" href="index.php">Home</a>
                  </li>
                 <!-- <li>
                    <a class="page-scroll" href="about.php">About</a>
                  </li> -->
                  <li class="active">
                    <a class="page-scroll" href="crowdfund.php">Crowdfund</a>
                  </li>
                  <!-- <li>
                    <a class="page-scroll" href="gallery.php">Gallery</a>
                  </li>-->
                  <li>
                    <a class="page-scroll" href="contact.php">Contact</a>
                  </li>
                </ul>
              </div>
              <!-- navbar-collapse -->
            </nav>
            <!-- END: Navigation -->
          </div>
        </div>
      </div>
    </div>
    <!-- header-area end -->
  </header>
   <br>
  <br>
  <div id="about" class="about-area area-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2>Crowdfund Us</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <!-- single-well start
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div class="well-left">
            <div class="single-well">
              <a href="#">
								  <img src="img/about/1.jpg" alt="">
								</a>
            </div>
          </div>
        </div> 
        <!-- single-well end-->
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="well-middle">
            <div class="single-well">
              <a href="#">
                <!-- <h4 class="sec-head">About Mavericks</h4> -->
              </a>
              <p>
TCET is participating in 3 competitions ie Aerodesign,BAJA,HVC which is under SAE . The team is formed by undergraduate students from mechanical department the aim is to gain better knowledge and experience above the academic level . The competition is  not won soley by the team  with the perfect pilot but also  by team  overall performance in various domains like
construction,fabrication,analysis and project planning.
We have everything it takes to build and successfully launch a crowdfunding campaign . Our team will collaborate to determine the strengths,weaknesses,opportunities and threats, then we will work together to provide the most immersive and individualized strategy for the competition
<br>
Together we’ll set goals and develop the best plan to meet ,then work with every set of the way to ensure crowdfunding campaign  as a success

              </p>

            </div>
          </div>
        </div>
        <!-- End col-->
      </div>
    </div>
  </div>
   <div id="about" class="about-area area-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2>Payment Details</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <!-- single-well start -->
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div class="well-left">
            <div class="single-well">
              <a href="#">
								  <img src="img/mr5.jpg" alt="">
								</a>
            </div>
          </div>
        </div> 
        <!-- single-well end-->
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div class="well-middle">
            <div class="single-well">
                            <a href="#">
                 <h4 class="sec-head">Bank Details</h4> 
              </a>
            <b>  <p>
                  Name - Uchit Shah <br>
IFSC code - SRCB0000099<br>
Account number - 099203100006094<br>
Bank: Saraswat co-operative bank</b>

              </p>
                       <br><br>     <a href="#">
                 <h4 class="sec-head">Paytm</h4> 
              </a>
            <b>  <p>Paytm - 8850200871 <br>
                 
              </p>
              
            </div>
          </div>
        </div>
        <!-- End col-->
      </div>
    </div>
  </div>
  
   <div class="container">
        <div class="row">
          <div class="col-md-2 col-sm-2 col-xs-12">
              </div>
        
              <div style="text-align:center" class="col-md-8 col-sm-8 col-xs-12">
                    <h2> 1000 </h2><h3> Rs Raised  </h3>
  <div class="progress">
   
  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="5"
  aria-valuemin="0" aria-valuemax="100" style="width:3%">
    2.5% Complete
  </div>
</div>
 <h3> Goal: Rs.4,00,000
<br> </h3>
</div>
          <div class="col-md-2 col-sm-2 col-xs-12">
              </div>
              </div>
              </div>
  <br><br>
  <footer>
      <div class="footer-area-bottom">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="copyright text-center">
              <p>
                &copy; Copyright <strong>Mavericks Racing</strong>. All Rights Reserved
              </p>
            </div>
            <div class="credits">
              Made With ❤️ By <a href="https://designandcode.in">Design & Code</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>