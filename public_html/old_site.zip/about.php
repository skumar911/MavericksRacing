<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Mavericks Racing</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700|Raleway:300,400,400i,500,500i,700,800,900" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/nivo-slider/css/nivo-slider.css" rel="stylesheet">
  <link href="lib/owlcarousel/owl.carousel.css" rel="stylesheet">
  <link href="lib/owlcarousel/owl.transitions.css" rel="stylesheet">
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/venobox/venobox.css" rel="stylesheet">

  <!-- Nivo Slider Theme -->
  <link href="css/nivo-slider-theme.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">

  <!-- Responsive Stylesheet File -->
  <link href="css/responsive.css" rel="stylesheet">
  
  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/venobox/venobox.min.js"></script>
  <script src="lib/knob/jquery.knob.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/parallax/parallax.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/nivo-slider/js/jquery.nivo.slider.js" type="text/javascript"></script>
  <script src="lib/appear/jquery.appear.js"></script>
  <script src="lib/isotope/isotope.pkgd.min.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <script src="js/main.js"></script>
  <!-- =======================================================
    Theme Name: eBusiness
    Theme URL: https://bootstrapmade.com/ebusiness-bootstrap-corporate-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
  ======================================================= -->
</head>

<body data-spy="scroll" data-target="#navbar-example">

  <div id="preloader"></div>

  <header>
    <!-- header-area start -->
    <div id="sticker" class="header-area">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12">

            <!-- Navigation -->
            <nav class="navbar navbar-default">
              <!-- Brand and toggle get grouped for better mobile display -->
              <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".bs-example-navbar-collapse-1" aria-expanded="false">
										<span class="sr-only">Toggle navigation</span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
									</button>
                <!-- Brand -->
                <a class="navbar-brand page-scroll sticky-logo" href="index.html">
                  <h1><span>M</span>avericks</h1>
                  <!-- Uncomment below if you prefer to use an image logo -->
                  <!-- <img src="img/logo.png" alt="" title=""> -->
								</a>
              </div>
              <!-- Collect the nav links, forms, and other content for toggling -->
              <div class="collapse navbar-collapse main-menu bs-example-navbar-collapse-1" id="navbar-example">
                <ul class="nav navbar-nav navbar-right">
                  <li>
                    <a class="page-scroll" href="index.php">Home</a>
                  </li>
                 <!-- <li class="active">
                    <a class="page-scroll" href="about.php">About</a>
                  </li> -->
                  <li>
                    <a class="page-scroll" href="crowdfund.php">Crowdfund</a>
                  </li>
                  <!-- <li>
                    <a class="page-scroll" href="gallery.php">Gallery</a>
                  </li> -->
                  <li>
                    <a class="page-scroll" href="contact.php">Contact</a>
                  </li>
                </ul>
              </div>
              <!-- navbar-collapse -->
            </nav>
            <!-- END: Navigation -->
          </div>
        </div>
      </div>
    </div>
    <!-- header-area end -->
  </header>
  <br>
  <br>
  <div id="about" class="about-area area-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2>About Competition</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <!-- single-well start
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div class="well-left">
            <div class="single-well">
              <a href="#">
								  <img src="img/about/1.jpg" alt="">
								</a>
            </div>
          </div>
        </div> 
        <!-- single-well end-->
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="well-middle">
            <div class="single-well">
              <a href="#">
                <!-- <h4 class="sec-head">About Mavericks</h4> -->
              </a>
              <p>
The purpose of the SAEISS Aero Design Challenge is to promote and develop Indian expertise and experience in unmanned systems technologies at the university and college levels. Even small scale unmanned vehicles are complex systems requiring a well planned and executed design approach. In addition, safety considerations are important factors in this competition as in any other vehicle design project.
<br>
The competition is intended to provide undergraduate and graduate engineering students with a real-life engineering challenge. It has been designed to provide exposure to the kinds of situations that engineers face in their real-life work environment. Each team is required to conceive, design and develop a prototype of fixed wing UAV meeting the mission requirements. First and foremost a design competition, students will find themselves performing trade studies and making compromises to arrive at a design solution that will optimally meet the mission requirements while still conforming to the configuration limitations.

              </p>

            </div>
          </div>
        </div>
        <!-- End col-->
      </div>
    </div>
  </div>
   <div id="about" class="about-area area-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2>About Team</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <!-- single-well start -->
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div class="well-left">
            <div class="single-well">
              <a href="#">
								  <img src="img/mr12.jpg" alt=""><img src="img/mr13.jpg" alt="">
								</a>
            </div>
          </div>
        </div> 
        <!-- single-well end-->
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div class="well-middle">
            <div class="single-well">
              <a href="#">
                <!-- <h4 class="sec-head">About Mavericks</h4> -->
              </a>
              <p>

AIRHAWKS is a team of official students of mechanical department  representing thakur college of engineering in the competition .  The team consists of various domains.

Each  member contributes  towards  the  team  in  his  specialized area  of  interest  namely  DESIGN,PRODUCTION, CAD/CAE,MARKETING etc.

The main objective of the competition is to experience and adapt knowledge about the design fabrication of Rc plane
              </p>

            </div>
          </div>
        </div>
        <!-- End col-->
      </div>
    </div>
  </div>
  <br><br>
  <footer>
      <div class="footer-area-bottom">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="copyright text-center">
              <p>
                &copy; Copyright <strong>Mavericks Racing</strong>. All Rights Reserved
              </p>
            </div>
            <div class="credits">
              Made With ❤️ By <a href="https://designandcode.in">Design & Code</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>